<?php

    $loader = require __DIR__ . '/../vendor/autoload.php';
    $loader->addPsr4('Ratchet\\', __DIR__ . '/helpers/Ratchet');
